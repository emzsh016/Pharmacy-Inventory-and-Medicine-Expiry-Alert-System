/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scd_aea;

/**
 *
 * @author Eman Fatima
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.JTableHeader;

public class BeautyUI {

    // Apply beauty to a full JFrame
    public static void beautifyFrame(JFrame frame) {
        frame.setSize(500, 500);
        frame.setLocationRelativeTo(null); // Center on screen
        frame.getContentPane().setBackground(new Color(245, 249, 255)); // Soft white-blue
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // Apply beauty to a Panel
    public static void beautifyPanel(JPanel panel) {
        panel.setBackground(new Color(245, 249, 255));
        panel.setBorder(new EmptyBorder(20, 25, 20, 25)); // Padding
        panel.setLayout(new GridLayout(0, 1, 10, 10)); // Spacing
    }

    // Style a Label
    public static void beautifyLabel(JLabel label) {
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setForeground(new Color(30, 30, 30));
    }

    // Style a TextField
    public static void beautifyTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBackground(Color.WHITE);
        field.setBorder(new LineBorder(new Color(180, 180, 200), 2, true));
        field.setPreferredSize(new Dimension(200, 35));
    }

    // Style a PasswordField
    public static void beautifyPassword(JPasswordField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(new LineBorder(new Color(180, 180, 200), 2, true));
        field.setBackground(Color.WHITE);
        field.setPreferredSize(new Dimension(200, 35));
    }

    // Style a Button
    public static void beautifyButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180)); // Steel blue
        button.setForeground(Color.WHITE);
        button.setBorder(new LineBorder(new Color(50, 90, 140), 2, true));
        button.setPreferredSize(new Dimension(140, 40));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(90, 150, 200));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(70, 130, 180));
            }
        });
    }

    // Style a JTable
    public static void beautifyTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(30);
        table.setGridColor(new Color(200, 200, 220));
        table.setSelectionBackground(new Color(100, 140, 190));
        table.setSelectionForeground(Color.WHITE);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setBackground(new Color(230, 235, 245));
        header.setForeground(Color.BLACK);
    }

    private BeautyUI() {
    }
}
