/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scd_aea;

import java.util.ArrayList;
import java.util.List;

/**
 * Class to validate all user credentials.
 */
public class CredentialValidator {

    private static final String[] COMMON_PASSWORDS = {
            "123456", "123456789", "password", "admin", "qwerty", "111111", "12345678"
    };

    // ---------- Password Validation ----------
    public static List<String> validatePassword(String password) {
        List<String> errors = new ArrayList<>();

        if (password == null || password.isEmpty()) {
            errors.add("Password cannot be empty.");
            return errors;
        }

        if (password.contains(" ")) {
            errors.add("Password cannot contain spaces.");
        }

        if (password.length() < 8) {
            errors.add("Password must be at least 8 characters long.");
        }

        if (!password.matches(".*[A-Z].*")) {
            errors.add("Password must contain at least one uppercase letter (A–Z).");
        }

        if (!password.matches(".*[a-z].*")) {
            errors.add("Password must contain at least one lowercase letter (a–z).");
        }

        if (!password.matches(".*\\d.*")) {
            errors.add("Password must contain at least one digit (0–9).");
        }

        if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};:'\",.<>/?].*")) {
            errors.add("Password must contain at least one symbol (!@#$%^&* etc).");
        }

        for (String weak : COMMON_PASSWORDS) {
            if (password.equalsIgnoreCase(weak)) {
                errors.add("Password is too common and easily guessable.");
                break;
            }
        }

        return errors;
    }

    // ---------- Email Validation ----------
    public static List<String> validateEmail(String email) {
        List<String> errors = new ArrayList<>();

        if (email == null || email.isEmpty()) {
            errors.add("Email cannot be empty.");
            return errors;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            errors.add("Invalid email format. Example: user@gmail.com");
        }

        if (!email.contains(".")) {
            errors.add("Email must contain a domain extension (e.g., .com, .pk).");
        }

        return errors;
    }

    // ---------- Phone Validation ----------
    public static List<String> validatePhone(String phone) {
        List<String> errors = new ArrayList<>();

        if (phone == null || phone.isEmpty()) {
            errors.add("Phone number cannot be empty.");
            return errors;
        }

        if (!phone.matches("\\d{11}")) {
            errors.add("Phone number must be exactly 11 digits.");
        }

        if (!phone.startsWith("03")) {
            errors.add("Pakistani phone numbers must start with '03'.");
        }

        return errors;
    }

    // ---------- Username Validation ----------
    public static List<String> validateUsername(String username) {
        List<String> errors = new ArrayList<>();

        if (username == null || username.isEmpty()) {
            errors.add("Username cannot be empty.");
            return errors;
        }

        if (username.contains(" ")) {
            errors.add("Username cannot contain spaces.");
        }

        if (!username.matches("^[A-Za-z0-9_.-]+$")) {
            errors.add("Username can only contain letters, numbers, ., _ or -.");
        }

        if (username.length() < 4) {
            errors.add("Username must be at least 4 characters long.");
        }

        return errors;
    }

    // ---------- Full Name Validation ----------
    public static List<String> validateFullName(String name) {
        List<String> errors = new ArrayList<>();

        if (name == null || name.isEmpty()) {
            errors.add("Full name cannot be empty.");
            return errors;
        }

        if (!name.matches("^[A-Za-z ]+$")) {
            errors.add("Full name may only contain letters and spaces.");
        }

        if (!name.trim().contains(" ")) {
            errors.add("Full name must include at least first and last name.");
        }

        return errors;
    }

    // Prevent instantiation
    private CredentialValidator() {}
}
