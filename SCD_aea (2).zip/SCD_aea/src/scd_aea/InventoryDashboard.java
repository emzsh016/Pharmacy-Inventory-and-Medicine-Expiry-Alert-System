package scd_aea;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class InventoryDashboard extends JFrame {

    private final JTable table;
    private final DefaultTableModel model;
    private final JTextField searchField;

    public InventoryDashboard() {
        setTitle("💊 Pharmacy Inventory Dashboard");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ---------- HEADER ----------
        JLabel header = new JLabel("Pharmacy Inventory System", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 26));
        header.setOpaque(true);
        header.setBackground(new Color(34, 139, 34)); // pharmacy green
        header.setForeground(Color.WHITE);
        add(header, BorderLayout.NORTH);

        // ---------- TABLE ----------
        model = new DefaultTableModel(new String[]{"ID", "Medicine Name", "Quantity", "Price"}, 0);
        table = new JTable(model);
        table.setRowHeight(28);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 15));
        add(new JScrollPane(table), BorderLayout.CENTER);

        // ---------- SEARCH + BUTTONS ----------
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        searchField = new JTextField(20);
        JButton searchBtn = new JButton("🔍 Search");
        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton logoutBtn = new JButton("🚪 Logout");

        bottomPanel.add(new JLabel("Search Medicine:"));
        bottomPanel.add(searchField);
        bottomPanel.add(searchBtn);
        bottomPanel.add(refreshBtn);
        bottomPanel.add(logoutBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        // ---------- EVENTS ----------
        refreshBtn.addActionListener(e -> loadMedicines());
        logoutBtn.addActionListener(e -> {
            dispose();
            Loginn.showLogin(); // goes back to login screen
        });
        searchBtn.addActionListener(e -> searchMedicine());

        loadMedicines(); // initial load
    }

    // Load all medicines
    private void loadMedicines() {
        model.setRowCount(0);
        try (Connection conn = DBConnectionn.connect()) {
            String query = "SELECT * FROM Medicines";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                int id = rs.getInt("med_id");            // correct column
                String name = rs.getString("med_name");  // correct column
                int qty = rs.getInt("quantity");
                double price = rs.getDouble("price");
                model.addRow(new Object[]{id, name, qty, price});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading medicines: " + e.getMessage());
        }
    }

    // Search medicines by name
    private void searchMedicine() {
        String search = searchField.getText().trim();
        if (search.isEmpty()) {
            loadMedicines();
            return;
        }

        model.setRowCount(0);
        try (Connection conn = DBConnectionn.connect()) {
            String query = "SELECT * FROM Medicines WHERE med_name LIKE ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, "%" + search + "%");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("med_id");            // correct column
                String name = rs.getString("med_name");  // correct column
                int qty = rs.getInt("quantity");
                double price = rs.getDouble("price");
                model.addRow(new Object[]{id, name, qty, price});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "⚠️ Search failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InventoryDashboard().setVisible(true));
    }
}
