/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author Eman Fatima
 */
package scd_aea;
import javax.swing.*;
import java.awt.*;

public class SCD_aea {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Pharmacy Inventory System");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);

        // Background Image
        ImageIcon bgIcon = new ImageIcon("C:\\Users\\Eman Fatima\\Downloads\\pills-dark-environment.jpg");
        Image bgImg = bgIcon.getImage().getScaledInstance(800, 600, Image.SCALE_SMOOTH);
        bgIcon = new ImageIcon(bgImg);

        JLabel bgLabel = new JLabel(bgIcon);
        bgLabel.setBounds(0, 0, 800, 600);
        frame.add(bgLabel);

        // Title
        JLabel title = new JLabel("🏥 Pharmacy Inventory System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setBounds(200, 30, 600, 50);
        bgLabel.add(title);

        // Login Button
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(320, 200, 160, 50);
        BeautyUI.beautifyButton(loginButton);
        bgLabel.add(loginButton);

        // Register Button
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(320, 270, 160, 50);
        BeautyUI.beautifyButton(registerButton);
        bgLabel.add(registerButton);

        // Actions
        loginButton.addActionListener(e -> Loginn.showLogin());
        registerButton.addActionListener(e -> Registerr.showRegister());

        frame.setVisible(true);
    }
}

