/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scd_aea;

/**
 *
 * @author Eman Fatima
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBConnectionn {

    // Your local SQL Server name and database
    private static final String SERVER_NAME = "EMAN-FATIMA";
    private static final String DATABASE_NAME = "PharmacyInventory";

    /**
     * Connects to SQL Server using Windows Authentication.
     * No username/password needed; uses your logged-in Windows account.
     * @return 
     */
    public static Connection connect() {
        Connection conn = null;
        try {
            // JDBC URL for Windows Authentication
            String url = String.format(
                "jdbc:sqlserver://%s;databaseName=%s;integratedSecurity=true;encrypt=false;",
                SERVER_NAME, DATABASE_NAME
            );

            // Establish connection
            conn = DriverManager.getConnection(url);
            System.out.println("✅ Connected to SQL Server successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "❌ Connection failed: " + e.getMessage(),
                    "Database Connection Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        return conn;
    }

    // Simple test method
    public static void main(String[] args) {
        Connection connection = connect();
        if (connection != null) {
            System.out.println("You can now use this connection in your GUI classes.");
        }
    }
}
