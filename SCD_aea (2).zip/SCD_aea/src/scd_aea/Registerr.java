package scd_aea;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Registerr {

    public static void showRegister() {

        JFrame frame = new JFrame("User Registration");
        frame.setSize(500, 650);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 248, 255));

        // ---------- Labels & Fields ----------
        JLabel title = new JLabel("User Registration Form");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBounds(120, 10, 300, 30);
        frame.add(title);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(30, 60, 120, 25);
        JTextField txtUsername = new JTextField();
        txtUsername.setBounds(160, 60, 280, 25);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(30, 100, 120, 25);
        JPasswordField txtPassword = new JPasswordField();
        txtPassword.setBounds(160, 100, 280, 25);

        JLabel lblName = new JLabel("Full Name:");
        lblName.setBounds(30, 140, 120, 25);
        JTextField txtName = new JTextField();
        txtName.setBounds(160, 140, 280, 25);

        JLabel lblPhone = new JLabel("Phone:");
        lblPhone.setBounds(30, 180, 120, 25);
        JTextField txtPhone = new JTextField();
        txtPhone.setBounds(160, 180, 280, 25);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(30, 220, 120, 25);
        JTextField txtEmail = new JTextField();
        txtEmail.setBounds(160, 220, 280, 25);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(30, 260, 120, 25);
        JTextField txtAge = new JTextField();
        txtAge.setBounds(160, 260, 280, 25);

        JLabel lblGender = new JLabel("Gender:");
        lblGender.setBounds(30, 300, 120, 25);
        String[] genders = {"Male", "Female", "Other"};
        JComboBox<String> cmbGender = new JComboBox<>(genders);
        cmbGender.setBounds(160, 300, 280, 25);

        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setBounds(30, 340, 120, 25);
        JTextField txtAddress = new JTextField();
        txtAddress.setBounds(160, 340, 280, 25);

        JLabel lblCity = new JLabel("City:");
        lblCity.setBounds(30, 380, 120, 25);
        JTextField txtCity = new JTextField();
        txtCity.setBounds(160, 380, 280, 25);

        JLabel lblCountry = new JLabel("Country:");
        lblCountry.setBounds(30, 420, 120, 25);
        JTextField txtCountry = new JTextField();
        txtCountry.setBounds(160, 420, 280, 25);

        frame.add(lblUsername); frame.add(txtUsername);
        frame.add(lblPassword); frame.add(txtPassword);
        frame.add(lblName); frame.add(txtName);
        frame.add(lblPhone); frame.add(txtPhone);
        frame.add(lblEmail); frame.add(txtEmail);
        frame.add(lblAge); frame.add(txtAge);
        frame.add(lblGender); frame.add(cmbGender);
        frame.add(lblAddress); frame.add(txtAddress);
        frame.add(lblCity); frame.add(txtCity);
        frame.add(lblCountry); frame.add(txtCountry);

        // ---------- Register Button ----------
        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(180, 480, 140, 40);
        registerBtn.setBackground(new Color(46, 139, 87));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerBtn.setFocusPainted(false);
        frame.add(registerBtn);

        // ---------- Button Action ----------
        registerBtn.addActionListener(e -> {

            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            String name = txtName.getText().trim();
            String phone = txtPhone.getText().trim();
            String email = txtEmail.getText().trim();
            String ageStr = txtAge.getText().trim();
            String gender = cmbGender.getSelectedItem().toString();
            String address = txtAddress.getText().trim();
            String city = txtCity.getText().trim();
            String country = txtCountry.getText().trim();

            List<String> errors = new ArrayList<>();
            errors.addAll(CredentialValidator.validateUsername(username));
            errors.addAll(CredentialValidator.validatePassword(password));
            errors.addAll(CredentialValidator.validateFullName(name));
            errors.addAll(CredentialValidator.validatePhone(phone));
            errors.addAll(CredentialValidator.validateEmail(email));

            // Age validation
            int age = 0;
            try {
                age = Integer.parseInt(ageStr);
                if (age < 16) errors.add("Age must be at least 16.");
            } catch (Exception ex) {
                errors.add("Age must be a number.");
            }

            // Non-empty fields
            if (address.isEmpty()) errors.add("Address cannot be empty.");
            if (city.isEmpty()) errors.add("City cannot be empty.");
            if (country.isEmpty()) errors.add("Country cannot be empty.");

            // Display all errors if any
            if (!errors.isEmpty()) {
                JOptionPane.showMessageDialog(frame,
                        String.join("\n", errors),
                        "Validation Errors", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Insert into DB
            try (Connection conn = DBConnectionn.connect()) {

                String query = """
                        INSERT INTO Users(username, password, full_name, phone, email, age, gender, address, city, country)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """;

                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, username);
                pst.setString(2, password);
                pst.setString(3, name);
                pst.setString(4, phone);
                pst.setString(5, email);
                pst.setInt(6, age);
                pst.setString(7, gender);
                pst.setString(8, address);
                pst.setString(9, city);
                pst.setString(10, country);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(frame,
                        "✅ Registration Successful!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);

                frame.dispose();
                new InventoryDashboard().setVisible(true);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame,
                        "❌ DB Error: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }

        });

        frame.setVisible(true);
    }

    private Registerr() {
    }
}
