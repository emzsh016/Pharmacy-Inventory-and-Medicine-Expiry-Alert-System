/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Eman Fatima
 */
package scd_aea;



import javax.swing.*;
import java.sql.*;
import java.util.List;

public class Loginn {

    public static void showLogin() {

        // Frame
        JFrame frame = new JFrame("Login");
        BeautyUI.beautifyFrame(frame);

        // Panel
        JPanel panel = new JPanel();
        BeautyUI.beautifyPanel(panel);
        frame.add(panel);

        // Username
        JLabel userLabel = new JLabel("Username:");
        BeautyUI.beautifyLabel(userLabel);
        panel.add(userLabel);

        JTextField userText = new JTextField();
        BeautyUI.beautifyTextField(userText);
        panel.add(userText);

        // Password
        JLabel passLabel = new JLabel("Password:");
        BeautyUI.beautifyLabel(passLabel);
        panel.add(passLabel);

        JPasswordField passText = new JPasswordField();
        BeautyUI.beautifyPassword(passText);
        panel.add(passText);

        // Login button
        JButton loginButton = new JButton("Login");
        BeautyUI.beautifyButton(loginButton);
        panel.add(loginButton);

        // Logic
        loginButton.addActionListener(e -> {
            String username = userText.getText().trim();
            String password = new String(passText.getPassword()).trim();

            // Basic check
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                return;
            }

            // Validate username
            List<String> userErrors = CredentialValidator.validateUsername(username);
            if (!userErrors.isEmpty()) {
                JOptionPane.showMessageDialog(frame, String.join("\n", userErrors));
                return;
            }

            try (Connection conn = DBConnectionn.connect()) {
                if (conn != null) {
                    String query = "SELECT * FROM Users WHERE username=? AND password=?";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, username);
                    pst.setString(2, password);
                    ResultSet rs = pst.executeQuery();

                    if (rs.next()) {
                        JOptionPane.showMessageDialog(frame, "Login Successful!");
                        frame.dispose();
                        new InventoryDashboard().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Invalid username or password.");
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "DB Error: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private Loginn() {}
}

