/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pharmacysystem;

/**
 *
 * @author Eman Fatima
 */
import java.util.*;

public class PharmacySystem {

    
    private String medicineName;
    private String batchNo;
    private Date expiryDate;
    private int quantity;
    private double price;

    
    private static final List<PharmacySystem> inventory = new ArrayList<>();

    
    public PharmacySystem(String name, String batch, Date expiry, int qty, double price) {
        this.medicineName = name;
        this.batchNo = batch;
        this.expiryDate = expiry;
        this.quantity = qty;
        this.price = price;
    }

   
    public String getMedicineName() { return medicineName; }
    public void setMedicineName(String medicineName) { this.medicineName = medicineName; }

    public String getBatchNo() { return batchNo; }
    public void setBatchNo(String batchNo) { this.batchNo = batchNo; }

    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date expiryDate) { this.expiryDate = expiryDate; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public static void addMedicine(PharmacySystem med) {
        inventory.add(med);
    }

    public static void addMedicine(String name, String batch, Date expiry, int qty, double price) {
        inventory.add(new PharmacySystem(name, batch, expiry, qty, price));
    }

  
    public boolean isNearExpiry(int days) {
        long diff = expiryDate.getTime() - new Date().getTime();
        long daysLeft = diff / (1000 * 60 * 60 * 24);
        return daysLeft <= days;
    }

   
    public static void showInventory() {
        System.out.println("\n--- Current Inventory ---");
        for (PharmacySystem med : inventory) {
            System.out.println(med.medicineName + " | Batch: " + med.batchNo + 
                               " | Qty: " + med.quantity + " | Expiry: " + med.expiryDate);
        }
    }

    
    public static void main(String[] args) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 5);  // Expiring in 5 days
        addMedicine("Paracetamol", "B01", c.getTime(), 50, 12.5);

        c.add(Calendar.DATE, 30); // Expiring in 35 days
        addMedicine("Amoxicillin", "B02", c.getTime(), 25, 22.0);

        showInventory();

        System.out.println("\n--- Expiry Alerts (within 10 days) ---");
        for (PharmacySystem med : inventory) {
            if (med.isNearExpiry(10)) {
                System.out.println("!!! " + med.getMedicineName() + " is near expiry!");
            }
        }
    }
}
