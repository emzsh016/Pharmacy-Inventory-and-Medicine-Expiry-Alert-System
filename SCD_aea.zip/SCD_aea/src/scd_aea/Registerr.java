/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package scd_aea;

/**
 *
 * @author Eman Fatima
 */



import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Registerr {

    public static void showRegister() {
        JFrame frame = new JFrame("Register");
        frame.setSize(350, 250);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(20, 20, 80, 25);
        frame.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(120, 20, 165, 25);
        frame.add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(20, 60, 80, 25);
        frame.add(passLabel);

        JPasswordField passText = new JPasswordField();
        passText.setBounds(120, 60, 165, 25);
        frame.add(passText);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(120, 100, 100, 25);
        frame.add(registerButton);

        registerButton.addActionListener((ActionEvent e) -> {
            String username = userText.getText();
            String password = new String(passText.getPassword());
            
            try (Connection conn = DBConnectionn.connect()) {
                if (conn != null) {
                    String query = "INSERT INTO Users(username, password) VALUES(?, ?)";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, username);
                    pst.setString(2, password);
                    int rows = pst.executeUpdate();
                    if (rows > 0) {
                        JOptionPane.showMessageDialog(frame, "✅ Registration successful!");
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "DB Error: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private Registerr() {
    }
}


