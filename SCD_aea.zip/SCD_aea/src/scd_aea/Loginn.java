/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Eman Fatima
 */
package scd_aea;


import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Loginn {

    public static void showLogin() {
        JFrame frame = new JFrame("Login");
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(20, 20, 80, 25);
        frame.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(120, 20, 165, 25);
        frame.add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(20, 60, 80, 25);
        frame.add(passLabel);

        JPasswordField passText = new JPasswordField();
        passText.setBounds(120, 60, 165, 25);
        frame.add(passText);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(120, 100, 80, 25);
        frame.add(loginButton);

        loginButton.addActionListener((ActionEvent e) -> {
            String username = userText.getText();
            String password = new String(passText.getPassword());
            
            try (Connection conn = DBConnectionn.connect()) {
                if (conn != null) {
                    String query = "SELECT * FROM Users WHERE username=? AND password=?";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, username);
                    pst.setString(2, password);
                    ResultSet rs = pst.executeQuery();
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(frame, "✅ Login successful!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "❌ Invalid credentials!");
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "DB Error: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private Loginn() {
    }
}
