/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package scd_aea;

/**
 *
 * @author Eman Fatima
 */


import javax.swing.*;
import java.awt.*;

public class SCD_aea {

    public static void main(String[] args) {
        // Main frame
        JFrame frame = new JFrame("Pharmacy Inventory System");
        frame.setSize(800, 600); // bigger window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); // center screen
        frame.setLayout(null);

        // Background image
        ImageIcon bgIcon = new ImageIcon("C:\\Users\\Eman Fatima\\Downloads\\flat-lay-pills-green-background.jpg"); 
        // Scale image to fit the window
        Image bgImg = bgIcon.getImage().getScaledInstance(800, 600, Image.SCALE_SMOOTH);
        bgIcon = new ImageIcon(bgImg);

        JLabel bgLabel = new JLabel(bgIcon);
        bgLabel.setBounds(0, 0, 800, 600);
        frame.add(bgLabel);

        // Header title on top of background
        JLabel title = new JLabel("🏥 Pharmacy Inventory System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBounds(20, 20, 600, 40);
        bgLabel.add(title); // add on background label

        // Buttons on top of background
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(320, 200, 160, 50);
        loginButton.setBackground(new Color(0, 123, 255));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        loginButton.setFocusPainted(false);
        bgLabel.add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(320, 270, 160, 50);
        registerButton.setBackground(new Color(40, 167, 69));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 18));
        registerButton.setFocusPainted(false);
        bgLabel.add(registerButton);

       
        // Button actions
        loginButton.addActionListener(e -> Loginn.showLogin());
        registerButton.addActionListener(e -> Registerr.showRegister());
       

        frame.setVisible(true);
    }
}
